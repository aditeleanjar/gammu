WAP
===

.. doxygenfunction:: GSM_EncodeURLFile
.. doxygenfunction:: GSM_GetWAPBookmark
.. doxygenfunction:: GSM_SetWAPBookmark
.. doxygenfunction:: GSM_DeleteWAPBookmark
.. doxygenfunction:: GSM_GetWAPSettings
.. doxygenfunction:: GSM_SetWAPSettings
.. doxygenstruct:: GSM_WAPBookmark
.. doxygenenum:: WAPSettings_Speed
.. doxygenenum:: WAPSettings_Bearer
.. doxygenstruct:: GSM_WAPSettings
.. doxygenstruct:: GSM_MultiWAPSettings
