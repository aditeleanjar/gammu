Ringtone
========

.. doxygenfunction:: PHONE_RTTLPlayOneNote
.. doxygenfunction:: PHONE_Beep
.. doxygenfunction:: GSM_GetRingtone
.. doxygenfunction:: GSM_SetRingtone
.. doxygenfunction:: GSM_GetRingtonesInfo
.. doxygenfunction:: GSM_DeleteUserRingtones
.. doxygenfunction:: GSM_PlayTone
.. doxygenfunction:: GSM_RingtoneConvert
.. doxygenfunction:: GSM_ReadRingtoneFile
.. doxygenfunction:: GSM_SaveRingtoneFile
.. doxygenfunction:: GSM_SaveRingtoneOtt
.. doxygenfunction:: GSM_SaveRingtoneMidi
.. doxygenfunction:: GSM_SaveRingtoneIMelody
.. doxygenfunction:: GSM_SaveRingtoneWav
.. doxygenfunction:: GSM_SaveRingtoneRttl
.. doxygenfunction:: GSM_GetRingtoneName
.. doxygenfunction:: GSM_RTTLGetTempo
.. doxygenenum:: GSM_RingNoteStyle
.. doxygenenum:: GSM_RingNoteNote
.. doxygenenum:: GSM_RingNoteDuration
.. doxygenenum:: GSM_RingNoteDurationSpec
.. doxygenenum:: GSM_RingNoteScale
.. doxygenstruct:: GSM_RingNote
.. doxygenenum:: GSM_RingCommandType
.. doxygenstruct:: GSM_RingCommand
.. doxygenstruct:: GSM_NoteRingtone
.. doxygenstruct:: GSM_NokiaBinaryRingtone
.. doxygenstruct:: GSM_BinaryTone
.. doxygenenum:: GSM_RingtoneFormat
.. doxygenstruct:: GSM_Ringtone
.. doxygenstruct:: GSM_RingtoneInfo
.. doxygenstruct:: GSM_AllRingtonesInfo
