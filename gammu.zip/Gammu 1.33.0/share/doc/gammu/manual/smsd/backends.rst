.. _smsd_services:

Backend services
----------------

The backend service is used to store messages (both incoming and queue of
outgoing ones).

.. toctree::
    :maxdepth: 2

    files
    sql
    mysql
    pgsql
    dbi
    odbc
    null
    tables

